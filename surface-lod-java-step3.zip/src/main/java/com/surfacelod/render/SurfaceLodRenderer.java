package com.surfacelod.render;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.surfacelod.config.LodConfig;
import com.surfacelod.config.LodQuality;
import com.surfacelod.config.RenderStyle;
import com.surfacelod.sample.ColumnCodec;
import com.surfacelod.sample.SurfaceLodStore;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import org.joml.Matrix4f;

/**
 * First real surface-LOD renderer. It turns sampled height columns into a cheap
 * camera-relative height-field mesh. It deliberately uses Minecraft's debug quad
 * render type so the first renderer has no texture/shader/resource dependency.
 */
public final class SurfaceLodRenderer {
    private static final int MIN_START_DISTANCE = 4;
    private static final float LOD_Y_OFFSET = -0.02f;

    private SurfaceLodRenderer() {}

    public static void register() {
        WorldRenderEvents.BEFORE_ENTITIES.register(SurfaceLodRenderer::render);
    }

    private static void render(WorldRenderContext context) {
        LodConfig config = LodConfig.get();
        if (!config.enabled || SurfaceLodStore.size() == 0) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        double camX = context.camera().getPosition().x;
        double camY = context.camera().getPosition().y;
        double camZ = context.camera().getPosition().z;
        int playerChunkX = ChunkPos.getX((long) Math.floor(camX / 16.0));
        int playerChunkZ = ChunkPos.getZ((long) Math.floor(camZ / 16.0));

        int vanillaDistance = 8;
        try {
            vanillaDistance = Math.max(MIN_START_DISTANCE, mc.options.renderDistance().get());
        } catch (Throwable ignored) {
            // Keep a safe fallback for launcher/mapping differences.
        }

        int startDistance = Math.max(MIN_START_DISTANCE, vanillaDistance + 1);
        int maxDistance = config.lodDistanceChunks;
        if (maxDistance <= startDistance) return;

        VertexConsumer buffer = context.consumers().getBuffer(RenderType.debugQuads());
        Matrix4f pose = context.matrices().last().pose();

        for (Long2ObjectMap.Entry<int[]> entry : SurfaceLodStore.entries()) {
            long key = entry.getLongKey();
            int cx = ChunkPos.getX(key);
            int cz = ChunkPos.getZ(key);
            int dx = cx - playerChunkX;
            int dz = cz - playerChunkZ;
            int dist = Math.max(Math.abs(dx), Math.abs(dz));
            if (dist <= startDistance || dist > maxDistance) continue;

            int step = stepFor(config.quality, dist, startDistance);
            renderChunk(buffer, pose, entry.getValue(), cx, cz, step, camY, config.renderStyle);
        }
    }

    private static int stepFor(LodQuality quality, int distance, int start) {
        int base = Math.max(1, quality.baseStep);
        int ring = Math.max(0, distance - start);
        int doublings = 0;
        while (ring > 8 && doublings < 4) {
            ring >>= 1;
            doublings++;
        }
        return Math.min(16, base << doublings);
    }

    private static void renderChunk(VertexConsumer buffer, Matrix4f pose, int[] samples,
                                    int chunkX, int chunkZ, int step, double cameraY,
                                    RenderStyle style) {
        final int baseX = chunkX << 4;
        final int baseZ = chunkZ << 4;

        for (int z = 0; z < 16; z += step) {
            for (int x = 0; x < 16; x += step) {
                int sample = chooseSample(samples, x, z, step);
                if (ColumnCodec.isEmpty(sample)) continue;

                int y = ColumnCodec.surfaceY(sample);
                int rgb = ColumnCodec.rgb888(sample);
                int r = (rgb >> 16) & 255;
                int g = (rgb >> 8) & 255;
                int b = rgb & 255;

                float shade = 1.0f;
                if (style == RenderStyle.SHADED) {
                    int neighbor = chooseSample(samples, Math.min(15, x + step), z, step);
                    if (!ColumnCodec.isEmpty(neighbor)) {
                        int dy = ColumnCodec.surfaceY(neighbor) - y;
                        shade = Math.max(0.55f, Math.min(1.05f, 1.0f - dy * 0.025f));
                    }
                }
                r = clamp((int) (r * shade));
                g = clamp((int) (g * shade));
                b = clamp((int) (b * shade));

                float x0 = baseX + x;
                float z0 = baseZ + z;
                float x1 = baseX + Math.min(16, x + step);
                float z1 = baseZ + Math.min(16, z + step);
                float yy = y + LOD_Y_OFFSET;

                addQuad(buffer, pose, x0, yy, z0, x1, z1, r, g, b, cameraY);
            }
        }
    }

    private static int chooseSample(int[] samples, int x, int z, int step) {
        int sx = Math.min(15, x + Math.max(0, step / 2));
        int sz = Math.min(15, z + Math.max(0, step / 2));
        return samples[(sz << 4) | sx];
    }

    private static void addQuad(VertexConsumer buffer, Matrix4f pose,
                                float x0, float y, float z0, float x1, float z1,
                                int r, int g, int b, double cameraY) {
        // Color-only debug quads; the matrix stack already contains Minecraft's camera transform.
        int a = 255;
        buffer.addVertex(pose, x0, y, z0).setColor(r, g, b, a);
        buffer.addVertex(pose, x0, y, z1).setColor(r, g, b, a);
        buffer.addVertex(pose, x1, y, z1).setColor(r, g, b, a);
        buffer.addVertex(pose, x1, y, z0).setColor(r, g, b, a);
    }

    private static int clamp(int v) {
        return Math.max(0, Math.min(255, v));
    }
}
