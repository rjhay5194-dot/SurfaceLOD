package com.surfacelod.sample;

import com.surfacelod.config.LodConfig;
import it.unimi.dsi.fastutil.longs.Long2ObjectLinkedOpenHashMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import net.minecraft.world.level.ChunkPos;

/** Compact client-side cache of sampled 16x16 surface columns. */
public final class SurfaceLodStore {
    private static final Long2ObjectLinkedOpenHashMap<int[]> CACHE = new Long2ObjectLinkedOpenHashMap<>();
    private static int maxChunks() {
        // One sample is 4 bytes. Keep the configured limit conservative and leave JVM headroom.
        long bytes = (long) LodConfig.get().cacheLimitMb * 1024L * 1024L;
        return (int) Math.max(64L, Math.min(8192L, bytes / (256L * 4L)));
    }

    private SurfaceLodStore() {}

    public static void put(long key, int[] samples) {
        int[] copy = samples.clone();
        CACHE.remove(key);
        CACHE.putAndMoveToFirst(key, copy);
        trim();
    }

    public static int[] get(long key) {
        int[] value = CACHE.getAndMoveToFirst(key);
        return value;
    }

    public static Iterable<Long2ObjectMap.Entry<int[]>> entries() {
        return CACHE.long2ObjectEntrySet();
    }

    public static int size() {
        return CACHE.size();
    }

    private static void trim() {
        int limit = maxChunks();
        while (CACHE.size() > limit) CACHE.removeLast();
    }

    public static void clear() {
        CACHE.clear();
    }

    public static long key(int chunkX, int chunkZ) {
        return ChunkPos.asLong(chunkX, chunkZ);
    }
}
