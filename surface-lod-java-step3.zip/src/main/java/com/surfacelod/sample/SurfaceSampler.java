package com.surfacelod.sample;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.levelgen.Heightmap;

/** Reads the top visible block of each column of an already-loaded client chunk. No allocation per call. */
public final class SurfaceSampler {
    public static final int COLUMNS = 256;
    private static final int FALLBACK_RGB = 0x808080;
    private static final BlockPos.MutableBlockPos POS = new BlockPos.MutableBlockPos();

    private SurfaceSampler() {}

    /** Must run on the client thread. out must have length 256, index = z * 16 + x. */
    public static void sampleChunk(LevelChunk chunk, int[] out) {
        final int minY = chunk.getMinY();
        final int baseX = chunk.getPos().getMinBlockX();
        final int baseZ = chunk.getPos().getMinBlockZ();
        final BlockPos.MutableBlockPos pos = POS;

        for (int z = 0; z < 16; z++) {
            for (int x = 0; x < 16; x++) {
                int i = (z << 4) | x;
                int top = chunk.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z) - 1;
                if (top < minY) {
                    out[i] = ColumnCodec.EMPTY;
                    continue;
                }
                int wx = baseX + x, wz = baseZ + z;
                int y = top;
                int depth = 0;
                // walk down through water to the floor
                while (y > minY && depth < 15) {
                    pos.set(wx, y, wz);
                    if (chunk.getBlockState(pos).getFluidState().isEmpty()) break;
                    depth++;
                    y--;
                }
                pos.set(wx, y, wz);
                BlockState floor = chunk.getBlockState(pos);
                int rgb = floor.getMapColor(chunk, pos).col;
                if (rgb == 0) rgb = FALLBACK_RGB;
                out[i] = ColumnCodec.pack(top, rgb, depth);
            }
        }
    }
}
