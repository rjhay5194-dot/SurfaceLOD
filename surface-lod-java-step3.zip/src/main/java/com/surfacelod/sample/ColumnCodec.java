package com.surfacelod.sample;

/**
 * One terrain column packed into a single int (4 bytes):
 * bits 0-11  : surface Y + 64 (0..4095)
 * bits 12-27 : colour as RGB565
 * bits 28-31 : water depth above the floor colour (0..15)
 * Value 0 means "no terrain".
 */
public final class ColumnCodec {
    public static final int EMPTY = 0;
    public static final int Y_OFFSET = 64;

    private ColumnCodec() {}

    public static int pack(int surfaceY, int rgb888, int waterDepth) {
        int y = Math.max(0, Math.min(4095, surfaceY + Y_OFFSET));
        int r = (rgb888 >> 16) & 0xFF, g = (rgb888 >> 8) & 0xFF, b = rgb888 & 0xFF;
        int c = ((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3);
        if (c == 0) c = 1; // keep non-empty columns distinguishable from EMPTY
        int d = Math.max(0, Math.min(15, waterDepth));
        return y | (c << 12) | (d << 28);
    }

    public static boolean isEmpty(int p) { return p == EMPTY; }
    public static int surfaceY(int p) { return (p & 0xFFF) - Y_OFFSET; }
    public static int waterDepth(int p) { return p >>> 28; }

    public static int rgb888(int p) {
        int c = (p >>> 12) & 0xFFFF;
        int r = ((c >> 11) & 31) * 255 / 31;
        int g = ((c >> 5) & 63) * 255 / 63;
        int b = (c & 31) * 255 / 31;
        return (r << 16) | (g << 8) | b;
    }
}
