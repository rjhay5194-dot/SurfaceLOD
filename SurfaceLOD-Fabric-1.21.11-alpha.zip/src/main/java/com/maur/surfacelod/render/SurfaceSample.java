package com.maur.surfacelod.render;

/**
 * Minimal representation intended for distant terrain.
 * No full chunk, block entities, entities, caves or inventories are retained.
 */
public record SurfaceSample(
        int chunkX,
        int chunkZ,
        int[] heights,
        int[] materials
) {
    public static final int GRID_SIZE = 4;

    public int sampleCount() {
        return heights.length;
    }
}
