package com.maur.surfacelod.render;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Small bounded cache. The final implementation will replace the source data
 * with compressed surface samples rather than retaining full Minecraft chunks.
 */
public final class SurfaceLodCache {
    private final int maxEntries;
    private final Map<Long, SurfaceSample> entries;

    public SurfaceLodCache(int maxEntries) {
        this.maxEntries = maxEntries;
        this.entries = new LinkedHashMap<>(64, 0.75f, true) {
            @Override
            protected boolean removeEldestEntry(Map.Entry<Long, SurfaceSample> eldest) {
                return size() > SurfaceLodCache.this.maxEntries;
            }
        };
    }

    public synchronized void put(long key, SurfaceSample sample) {
        entries.put(key, sample);
    }

    public synchronized SurfaceSample get(long key) {
        return entries.get(key);
    }

    public synchronized void clear() {
        entries.clear();
    }

    public synchronized int size() {
        return entries.size();
    }
}
