package com.maur.surfacelod.render;

import com.maur.surfacelod.config.LodConfig;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;

/**
 * Rendering shell for the Surface LOD system.
 *
 * Phase 1 deliberately does not fake distant terrain yet. It establishes the
 * bounded cache, update budget and render hook without touching Minecraft's
 * normal chunk renderer.
 *
 * Phase 2 will add a surface sampler that produces SurfaceSample objects
 * outside vanilla render distance.
 */
public final class SurfaceLodRenderer {
    private static final SurfaceLodCache CACHE = new SurfaceLodCache(1024);

    private static int tickBudgetAccumulator;

    private SurfaceLodRenderer() {}

    public static void init() {
        CACHE.clear();
    }

    public static void tick(MinecraftClient client) {
        if (!LodConfig.INSTANCE.enabled || client.world == null) return;

        // CPU mode controls how much future LOD work may be scheduled per tick.
        // No heavy work is performed on the render thread in this prototype.
        tickBudgetAccumulator += LodConfig.INSTANCE.cpuUsage;
        if (tickBudgetAccumulator > 1000) tickBudgetAccumulator = 1000;

        // Phase 2: consume a tiny bounded amount from a background work queue.
    }

    public static void render(WorldRenderContext context) {
        if (!LodConfig.INSTANCE.enabled || context.world() == null) return;

        // Renderer intentionally remains empty until the surface sampler and
        // mesh builder are added. This prevents the first prototype from
        // adding expensive work to every frame.
        //
        // Future path:
        // SurfaceSample -> low-poly mesh -> GPU buffer -> draw far terrain.
    }

    public static SurfaceLodCache cache() {
        return CACHE;
    }
}
