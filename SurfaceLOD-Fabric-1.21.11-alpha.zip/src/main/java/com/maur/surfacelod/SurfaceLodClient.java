package com.maur.surfacelod;

import com.maur.surfacelod.config.LodConfig;
import com.maur.surfacelod.render.SurfaceLodRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class SurfaceLodClient implements ClientModInitializer {
    public static final String MOD_ID = "surfacelod";

    private static KeyBinding toggleKey;

    @Override
    public void onInitializeClient() {
        LodConfig.load();

        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.surfacelod.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_F8,
                "category.surfacelod"
        ));

        SurfaceLodRenderer.init();

        WorldRenderEvents.AFTER_ENTITIES.register(SurfaceLodRenderer::render);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                LodConfig.INSTANCE.enabled = !LodConfig.INSTANCE.enabled;
                LodConfig.save();
            }

            SurfaceLodRenderer.tick(client);
        });
    }

    public static KeyBinding getToggleKey() {
        return toggleKey;
    }
}
