package com.maur.surfacelod.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class LodConfig {
    public static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    public static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("surfacelod.json");

    public static LodConfig INSTANCE = new LodConfig();

    public boolean enabled = true;

    // 1..5. Higher = more surface detail.
    public int quality = 3;

    // 1..5. Higher = more background work.
    public int cpuUsage = 2;

    // Distant LOD radius in chunks.
    public int lodDistance = 64;

    // Vanilla fog is disabled by the renderer/mixin in a later phase.
    public boolean disableVanillaFog = true;

    // Keeps old and new representations alive briefly during replacement.
    public boolean smoothTransition = true;

    private LodConfig() {}

    public static void load() {
        if (!Files.exists(FILE)) return;
        try {
            INSTANCE = GSON.fromJson(Files.readString(FILE), LodConfig.class);
            if (INSTANCE == null) INSTANCE = new LodConfig();
            INSTANCE.clamp();
        } catch (Exception ignored) {
            INSTANCE = new LodConfig();
        }
    }

    public static void save() {
        INSTANCE.clamp();
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(INSTANCE));
        } catch (IOException ignored) {
        }
    }

    private void clamp() {
        quality = Math.max(1, Math.min(5, quality));
        cpuUsage = Math.max(1, Math.min(5, cpuUsage));
        lodDistance = Math.max(8, Math.min(256, lodDistance));
    }
}
