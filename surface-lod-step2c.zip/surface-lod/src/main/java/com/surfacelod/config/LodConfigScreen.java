package com.surfacelod.config;

import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class LodConfigScreen {
    private LodConfigScreen() {}

    public static Screen create(Screen parent) {
        LodConfig c = LodConfig.get();
        LodConfig d = new LodConfig(); // defaults

        ConfigBuilder builder = ConfigBuilder.create()
                .setParentScreen(parent)
                .setTitle(Component.literal("Surface LOD"))
                .setSavingRunnable(() -> {
                    c.sanitize();
                    LodConfig.save();
                });
        ConfigEntryBuilder eb = builder.entryBuilder();

        ConfigCategory general = builder.getOrCreateCategory(Component.literal("General"));
        general.addEntry(eb.startBooleanToggle(Component.literal("Enable LOD"), c.enabled)
                .setDefaultValue(d.enabled)
                .setSaveConsumer(v -> c.enabled = v)
                .build());
        general.addEntry(eb.startEnumSelector(Component.literal("LOD quality"), LodQuality.class, c.quality)
                .setDefaultValue(d.quality)
                .setTooltip(Component.literal("Detail of the nearest LOD ring. Farther rings are coarser."))
                .setSaveConsumer(v -> c.quality = v)
                .build());
        general.addEntry(eb.startEnumSelector(Component.literal("CPU mode"), CpuMode.class, c.cpuMode)
                .setDefaultValue(d.cpuMode)
                .setTooltip(Component.literal("How much CPU time LOD work may use. Lower = smoother, slower loading."))
                .setSaveConsumer(v -> c.cpuMode = v)
                .build());
        general.addEntry(eb.startIntSlider(Component.literal("LOD distance (chunks)"), c.lodDistanceChunks,
                        LodConfig.MIN_DISTANCE_CHUNKS, LodConfig.MAX_DISTANCE_CHUNKS)
                .setDefaultValue(d.lodDistanceChunks)
                .setSaveConsumer(v -> c.lodDistanceChunks = v)
                .build());
        general.addEntry(eb.startIntSlider(Component.literal("LOD cache limit (MB)"), c.cacheLimitMb,
                        LodConfig.MIN_CACHE_MB, LodConfig.MAX_CACHE_MB)
                .setDefaultValue(d.cacheLimitMb)
                .setTooltip(Component.literal("Hard cap for LOD data kept in memory."))
                .setSaveConsumer(v -> c.cacheLimitMb = v)
                .build());
        general.addEntry(eb.startBooleanToggle(Component.literal("Disable vanilla fog"), c.disableVanillaFog)
                .setDefaultValue(d.disableVanillaFog)
                .setSaveConsumer(v -> c.disableVanillaFog = v)
                .build());

        ConfigCategory look = builder.getOrCreateCategory(Component.literal("Appearance"));
        look.addEntry(eb.startEnumSelector(Component.literal("Structures"), StructureMode.class, c.structureMode)
                .setDefaultValue(d.structureMode)
                .setTooltip(Component.literal("OFF, VISITED_ONLY (free), or MARKERS (boxes for unexplored structures)."))
                .setSaveConsumer(v -> c.structureMode = v)
                .build());
        look.addEntry(eb.startEnumSelector(Component.literal("Render style"), RenderStyle.class, c.renderStyle)
                .setDefaultValue(d.renderStyle)
                .setSaveConsumer(v -> c.renderStyle = v)
                .build());
        look.addEntry(eb.startBooleanToggle(Component.literal("Render water"), c.renderWater)
                .setDefaultValue(d.renderWater)
                .setSaveConsumer(v -> c.renderWater = v)
                .build());

        return builder.build();
    }
}
