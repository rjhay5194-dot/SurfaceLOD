package com.surfacelod.config;

/** How LOD terrain is coloured. */
public enum RenderStyle {
    /** Plain block colours. Cheapest. */
    FLAT,
    /** Slope-based shading baked into vertex colours. No extra GPU cost. */
    SHADED
}
