package com.surfacelod.config;

/** How distant structures (villages, temples, etc.) are shown in the LOD. */
public enum StructureMode {
    /** No special structure handling. */
    OFF,
    /** Only what you have already seen up close (roofs and walls come from sampled chunks). Free. */
    VISITED_ONLY,
    /** Also draw simple coloured boxes for structures in unexplored terrain (singleplayer only). */
    MARKERS
}
