package com.surfacelod.config;

/** Limits for background LOD work. Main-thread work per tick is capped by mainThreadBudgetMicros. */
public enum CpuMode {
    MINIMAL(1, 300),
    LOW(1, 800),
    BALANCED(2, 1500),
    FAST(2, 3000),
    MAXIMUM(3, 6000);

    public final int workerThreads;
    public final int mainThreadBudgetMicros;

    CpuMode(int workerThreads, int mainThreadBudgetMicros) {
        this.workerThreads = workerThreads;
        this.mainThreadBudgetMicros = mainThreadBudgetMicros;
    }
}
