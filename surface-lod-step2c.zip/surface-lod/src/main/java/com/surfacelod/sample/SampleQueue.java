package com.surfacelod.sample;

import com.surfacelod.SurfaceLodClient;
import com.surfacelod.config.LodConfig;
import it.unimi.dsi.fastutil.longs.LongArrayFIFOQueue;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.status.ChunkStatus;

/**
 * Chunks are queued when they load and sampled with a per-tick time budget.
 * If a queued chunk is about to unload, it is sampled immediately so the data is not lost.
 * Only chunk coordinates are held, never chunk objects.
 */
public final class SampleQueue {
    private static final LongArrayFIFOQueue QUEUE = new LongArrayFIFOQueue();
    private static final LongOpenHashSet PENDING = new LongOpenHashSet();
    private static final int[] SCRATCH = new int[SurfaceSampler.COLUMNS];
    private static final int MAX_PENDING = 4096;

    private static long sampledTotal = 0;

    private SampleQueue() {}

    public static void onChunkLoad(LevelChunk chunk) {
        if (!LodConfig.get().enabled) return;
        long key = chunk.getPos().toLong();
        if (PENDING.size() >= MAX_PENDING) return; // hard bound on queue size
        if (PENDING.add(key)) QUEUE.enqueue(key);
    }

    public static void onChunkUnload(LevelChunk chunk) {
        if (!LodConfig.get().enabled) return;
        if (PENDING.remove(chunk.getPos().toLong())) {
            process(chunk);
        }
    }

    public static void tick(Minecraft mc) {
        ClientLevel level = mc.level;
        if (level == null || QUEUE.isEmpty()) return;
        final long budgetNs = LodConfig.get().cpuMode.mainThreadBudgetMicros * 1000L;
        final long start = System.nanoTime();
        while (!QUEUE.isEmpty() && System.nanoTime() - start < budgetNs) {
            long key = QUEUE.dequeueLong();
            if (!PENDING.remove(key)) continue; // already handled at unload
            ChunkPos cp = new ChunkPos(key);
            LevelChunk chunk = level.getChunkSource().getChunk(cp.x, cp.z, ChunkStatus.FULL, false);
            if (chunk != null) process(chunk);
        }
    }

    private static void process(LevelChunk chunk) {
        SurfaceSampler.sampleChunk(chunk, SCRATCH);
        // Step 3 will hand SCRATCH to the compact storage here.
        sampledTotal++;
        if (sampledTotal == 1 || sampledTotal % 500 == 0) {
            int mid = SCRATCH[(8 << 4) | 8];
            SurfaceLodClient.LOG.info("Sampled {} chunks; centre column of last: y={} rgb={} water={}",
                    sampledTotal, ColumnCodec.surfaceY(mid),
                    Integer.toHexString(ColumnCodec.rgb888(mid)), ColumnCodec.waterDepth(mid));
        }
    }

    public static void clear() {
        QUEUE.clear();
        PENDING.clear();
    }
}
